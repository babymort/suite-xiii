#!/usr/bin/env node
// =====================================================================
//  GRAPHICO XIII — relais local (aucune dépendance : Node.js 14 ou plus)
//  node graphico-relay.js [port]        (port par défaut : 8787)
//  • sert graphico.html (placé à côté de ce fichier) : http://ADRESSE:8787/
//  • relaie les messages du pupitre vers toutes les sorties d'une même « salle » (WebSocket)
//  • garde en mémoire le dernier projet et le dernier état : une sortie qui se connecte en retard est servie aussitôt
// =====================================================================
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto'), os = require('os');
let PORT = +(process.argv[2] || process.env.PORT || 8787), DIR = __dirname, EXTRA = () => ({}), EMIT = () => { }, XIII = () => ({}), SEND = null, HOOKS = {}, HTTPH = {};
const lanIps = () => { const a = []; Object.values(os.networkInterfaces()).forEach(l => l.forEach(i => { if (i.family === 'IPv4' && !i.internal) a.push(i.address); })); return a; };
const rooms = new Map(); // salle -> { clients:Set, proj:string, state:string }
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.css': 'text/css', '.ico': 'image/x-icon' };

const server = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x'); let p = decodeURIComponent(u.pathname);
    if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, POST', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Private-Network': 'true' }); res.end(); return; }
    if (HTTPH[p]) { res.setHeader('Access-Control-Allow-Origin', '*'); res.setHeader('Access-Control-Allow-Private-Network', 'true'); let b = ''; req.on('data', d => { b += d; if (b.length > 1e5) req.destroy(); }); req.on('end', () => { let q = {}; try { q = b ? JSON.parse(b) : Object.fromEntries(u.searchParams); } catch (e) { } Promise.resolve(HTTPH[p](q)).then(r => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(r || { ok: true })); }, e => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ ok: false, err: String(e && e.message || e) })); }); }); return; }
    if (p === '/__xiii') { res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Private-Network': 'true', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(Object.assign({ xiii: true, relay: true, port: PORT, ips: lanIps() }, XIII()))); return; }
    if (p === '/__graphico') { res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Private-Network': 'true' }); res.end(JSON.stringify(Object.assign({ relay: true, port: PORT, ips: lanIps(), rooms: [...rooms.keys()], clients: [...rooms.values()].reduce((n, r) => n + r.clients.size, 0) }, EXTRA()))); return; }
    if (p === '/__cmd') { // Stream Deck / requêtes HTTP : /__cmd?room=salle&a=toggle&g=NOM[&pin=1234][&txt.CHAMP=valeur]
        const q = u.searchParams, name = (q.get('room') || 'salle').toLowerCase().slice(0, 40), room = rooms.get(name), vars = {}; q.forEach((v, k) => { if (k.indexOf('txt.') === 0) vars[k.slice(4)] = v; });
        const msg = JSON.stringify({ k: 'pad', a: q.get('a') || 'toggle', g: q.get('g') || '', pin: q.get('pin') || '', vars: Object.keys(vars).length ? vars : undefined, src: 'http', f: 'relay', id: 'relay.' + Date.now() + '.' + Math.random().toString(36).slice(2, 7), rid: 'relay' });
        let n = 0; if (room) room.clients.forEach(c => { if (c.role === 'ctl') { c.send(msg); n++; } });
        res.writeHead(n ? 200 : 404, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' }); res.end(JSON.stringify({ ok: !!n, pupitres: n, salle: name })); return;
    }
    if (p === '/' || p === '') p = '/graphico.html';
    const f = path.normalize(path.join(DIR, p)); if (f.indexOf(DIR) !== 0) { res.writeHead(403); res.end('403'); return; }
    fs.readFile(f, (e, d) => { if (e) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Fichier introuvable : ' + p + '\nPlacez graphico.html à côté de graphico-relay.js.'); return; } res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' }); res.end(d); });
});

// ----- WebSocket minimal (RFC 6455) : texte, fragmentation, ping/pong, grosses trames
function frame(op, payload) {
    const n = payload.length; let h;
    if (n < 126) h = Buffer.from([0x80 | op, n]); else if (n < 65536) { h = Buffer.alloc(4); h[0] = 0x80 | op; h[1] = 126; h.writeUInt16BE(n, 2); } else { h = Buffer.alloc(10); h[0] = 0x80 | op; h[1] = 127; h.writeUInt32BE(0, 2); h.writeUInt32BE(n, 6); }
    return Buffer.concat([h, payload]);
}
server.on('upgrade', (req, sock) => {
    const u = new URL(req.url, 'http://x'), key = req.headers['sec-websocket-key']; if (!key) { sock.destroy(); return; }
    const HK = u.pathname === '/__ndi/send' ? SEND : HOOKS[u.pathname];
    if (HK || u.pathname === '/__ndi/send' || u.pathname === '/__stream') { // NDI XIII : un outil de la suite publie une source NDI (texte = réglages JSON, binaire = 'V' + RGBA ou 'A' + PCM float)
        if (!HK) { sock.destroy(); return; }
        sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + crypto.createHash('sha1').update(key + GUID).digest('base64') + '\r\n\r\n');
        const h = { text: () => { }, bin: () => { }, close: () => { }, send(t) { try { sock.write(frame(1, Buffer.from(t, 'utf8'))); } catch (e) { } } }; let done = false; const end = () => { if (done) return; done = true; h.close(); };
        wsRead(sock, (op, d) => { if (op === 8) { try { sock.end(frame(8, Buffer.alloc(0))); } catch (e) { } end(); } else if (op === 9) sock.write(frame(10, d)); else if (op === 1) h.text(d.toString('utf8')); else if (op === 2) h.bin(d); });
        sock.on('close', end); sock.on('error', end); HK(h, u.searchParams); return;
    }
    sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + crypto.createHash('sha1').update(key + GUID).digest('base64') + '\r\n\r\n');
    const name = (u.searchParams.get('room') || 'salle').toLowerCase().slice(0, 40), role = u.searchParams.get('role') || 'out';
    let room = rooms.get(name); if (!room) { room = { clients: new Set(), proj: null, state: null }; rooms.set(name, room); }
    const c = { sock, role, send(t) { try { sock.write(frame(1, Buffer.from(t, 'utf8'))); } catch (e) { } } }; room.clients.add(c);
    log('+ ' + role + ' · salle « ' + name + ' » · ' + room.clients.size + ' connecté(s)'); EMIT('join', { room: name, role });
    if (role !== 'ctl') { if (room.proj) c.send(room.proj); if (room.state) c.send(room.state); }
    let buf = Buffer.alloc(0), parts = [], partOp = 0;
    const onFrame = (op, data) => {
        if (op === 8) { sock.end(frame(8, Buffer.alloc(0))); return; } if (op === 9) { sock.write(frame(10, data)); return; } if (op === 10) return;
        const txt = data.toString('utf8');
        if (txt.length < 400 || true) { try { const k = /"k":"(\w+)"/.exec(txt.slice(0, 200)); if (k) { if (k[1] === 'proj') room.proj = txt; else if (k[1] === 'state' && !/"src":"out"/.test(txt.slice(0, 120))) room.state = txt; } } catch (e) { } }
        room.clients.forEach(o => { if (o !== c) o.send(txt); });
    };
    sock.on('data', d => {
        buf = Buffer.concat([buf, d]);
        for (; ;) {
            if (buf.length < 2) return; const fin = buf[0] & 0x80, op = buf[0] & 15, masked = buf[1] & 0x80; let len = buf[1] & 127, off = 2;
            if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; } else if (len === 127) { if (buf.length < 10) return; len = buf.readUInt32BE(2) * 4294967296 + buf.readUInt32BE(6); off = 10; }
            const need = off + (masked ? 4 : 0) + len; if (buf.length < need) return;
            let data = buf.slice(off + (masked ? 4 : 0), need); if (masked) { const m = buf.slice(off, off + 4); data = Buffer.from(data); for (let i = 0; i < data.length; i++) data[i] ^= m[i & 3]; }
            buf = buf.slice(need);
            if (op === 0) { parts.push(data); if (fin) { const full = Buffer.concat(parts); parts = []; onFrame(partOp, full); } }
            else if (!fin) { partOp = op; parts = [data]; } else onFrame(op, data);
        }
    });
    const gone = () => { if (!room.clients.delete(c)) return; log('− ' + role + ' · salle « ' + name + ' » · ' + room.clients.size + ' connecté(s)'); if (!room.clients.size) setTimeout(() => { if (rooms.get(name) === room && !room.clients.size) rooms.delete(name); }, 3600000); };
    sock.on('close', gone); sock.on('error', gone); sock.on('end', gone);
});
function wsRead(sock, onFrame) {
    let buf = Buffer.alloc(0), parts = [], partOp = 0;
    sock.on('data', d => {
        buf = buf.length ? Buffer.concat([buf, d]) : d;
        for (; ;) {
            if (buf.length < 2) return; const fin = buf[0] & 0x80, op = buf[0] & 15, masked = buf[1] & 0x80; let len = buf[1] & 127, off = 2;
            if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; } else if (len === 127) { if (buf.length < 10) return; len = buf.readUInt32BE(2) * 4294967296 + buf.readUInt32BE(6); off = 10; }
            const need = off + (masked ? 4 : 0) + len; if (buf.length < need) return;
            let data = Buffer.from(buf.subarray(off + (masked ? 4 : 0), need)); if (masked) { const m = buf.subarray(off, off + 4); for (let i = 0; i < data.length; i++) data[i] ^= m[i & 3]; }
            buf = buf.subarray(need);
            if (op === 0) { parts.push(data); if (fin) { const full = Buffer.concat(parts); parts = []; onFrame(partOp, full); } }
            else if (!fin) { partOp = op; parts = [data]; } else onFrame(op, data);
        }
    });
}
let log = s => console.log(new Date().toTimeString().slice(0, 8) + '  ' + s);
function listen(cb) {
    server.listen(PORT, '0.0.0.0', cb);
    server.on('error', e => { if (module.exports.onError) module.exports.onError(e); else { console.error(e.code === 'EADDRINUSE' ? 'Le port ' + PORT + ' est déjà utilisé : essayez  node graphico-relay.js ' + (PORT + 1) : e.message); process.exit(1); } });
}
// utilisable comme module (Graphico NDI) : require('./graphico-relay.js').start({ port, dir, status, emit, log })
module.exports = {
    start(o) { o = o || {}; if (o.port) PORT = +o.port; if (o.dir) DIR = o.dir; if (o.status) EXTRA = o.status; if (o.xiii) XIII = o.xiii; if (o.send) SEND = o.send; if (o.hooks) HOOKS = o.hooks; if (o.http) HTTPH = o.http; if (o.emit) EMIT = o.emit; if (o.log) log = o.log; if (o.onError) module.exports.onError = o.onError; listen(o.ready); return { server, rooms, lanIps, get port() { return PORT; } }; },
    lanIps
};
if (require.main === module) listen(() => {
    const ips = lanIps();
    console.log('\n  GRAPHICO XIII — relais prêt\n');
    console.log('  Pupitre (régie) :  http://localhost:' + PORT + '/');
    ips.forEach(ip => console.log('  Autres machines :  http://' + ip + ':' + PORT + '/   (sorties : ajouter  &ws=auto  à l’adresse donnée par l’onglet « Sorties »)'));
    console.log('\n  Laissez cette fenêtre ouverte pendant le direct. Ctrl+C pour arrêter.\n');
});
