#!/bin/bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Installez Node.js (https://nodejs.org)"; exit 1; }
[ -d node_modules/electron/dist ] && [ -d node_modules/ffmpeg-static ] || npm install --no-audit --no-fund || exit 1
[ -x bin/linux-x64/ndi-send-local ] || { command -v cc >/dev/null && cc -O2 -o bin/linux-x64/ndi-send-local src/ndi-send.c -ldl -lpthread; }
./node_modules/.bin/electron . &
