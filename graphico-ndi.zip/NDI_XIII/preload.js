const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('gndi', {
    get: () => ipcRenderer.invoke('get'),
    set: (k, v) => ipcRenderer.invoke('set', k, v),
    open: w => ipcRenderer.invoke('open', w),
    copy: t => ipcRenderer.invoke('copy', t),
    onState: f => ipcRenderer.on('state', (e, s) => f(s))
});
