// =====================================================================
//  NDI XIII (ex-Graphico NDI) — le module NDI unique de la SUITE XIII, installé une fois sur l'ordinateur
//  • publie les sorties de GRAPHICO XIII en sources NDI (avec transparence)
//  • publie en NDI ce que les autres outils lui envoient (MELANGO programme…) : ws://127.0.0.1:8787/__ndi/send
//  • annonce sa présence aux outils : http://127.0.0.1:8787/__xiii
//  • intègre le relais (pupitre ⇄ sorties) et sert graphico.html : http://ADRESSE:8787
//  • chaque sortie est une page Graphico rendue hors écran (Electron) puis envoyée au runtime NDI par « ndi-send »
//  Application développée par Matthieu Lamotte — SUITE XIII.
//  NDI® est une marque déposée de Vizrt NDI AB.
// =====================================================================
const { app, BrowserWindow, ipcMain, shell, clipboard, session } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os'), { spawn } = require('child_process');
const relay = require('./graphico-relay.js');

app.commandLine.appendSwitch('force-device-scale-factor', '1');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
if (!app.requestSingleInstanceLock()) { app.quit(); }

const VERSION = '2.4';
const FPS = { '24': [24, 1], '25': [25, 1], '29.97': [30000, 1001], '30': [30, 1], '50': [50, 1], '59.94': [60000, 1001], '60': [60, 1] };
const DEF = { port: 8787, follow: true, room: '', w: 1920, h: 1080, fps: '25', unpremul: true, outs: [1, 2, 3, 4].map(n => ({ on: n === 1, name: 'GRAPHICO - Sortie ' + n, video: true, audio: { dev: '', label: '', chan: '12', gain: 0, mute: false } })) };
const ADEF = { dev: '', label: '', chan: '12', gain: 0, mute: false };
let audioWin = null, DEVICES = [];
let CFG, cfgPath, panel = null, srv = null, ROOM = '', LOGS = [], quitting = false;
const OUTS = {};

function loadCfg() {
    cfgPath = path.join(app.getPath('userData'), 'ndi-xiii.json'); const old = path.join(app.getPath('userData'), 'graphico-ndi.json'); if (!fs.existsSync(cfgPath) && fs.existsSync(old)) try { fs.copyFileSync(old, cfgPath); } catch (e) { }
    try { CFG = Object.assign({}, DEF, JSON.parse(fs.readFileSync(cfgPath, 'utf8'))); } catch (e) { CFG = JSON.parse(JSON.stringify(DEF)); }
    if (!Array.isArray(CFG.outs) || CFG.outs.length !== 4) CFG.outs = DEF.outs; if (!FPS[CFG.fps]) CFG.fps = '25';
    CFG.outs.forEach(o => { if (o.video == null) o.video = true; o.audio = Object.assign({}, ADEF, o.audio || {}); });
    ROOM = CFG.room || '';
}
function saveCfg() { try { fs.mkdirSync(path.dirname(cfgPath), { recursive: true }); fs.writeFileSync(cfgPath, JSON.stringify(CFG, null, 1)); } catch (e) { } }
function log(s) { const l = new Date().toTimeString().slice(0, 8) + '  ' + s; LOGS.push(l); if (LOGS.length > 200) LOGS.shift(); push(); }

// ---------- binaire d'envoi NDI ----------
function helperPath() {
    const b = path.join(__dirname, 'bin');
    if (process.platform === 'win32') return path.join(b, 'win-x64', 'ndi-send.exe');
    if (process.platform === 'darwin') { const loc = path.join(b, 'mac', 'ndi-send-local'); return fs.existsSync(loc) ? loc : path.join(b, 'mac', 'ndi-send'); }
    const loc = path.join(b, 'linux-x64', 'ndi-send-local'); return fs.existsSync(loc) ? loc : path.join(b, 'linux-x64', 'ndi-send');
}
let RUNTIME = null; // null : inconnu, true : présent, false : absent
// runtime NDI fourni avec le module (dossier runtime/) : utilisé en priorité, sinon celui de NDI Tools
function runtimeEnv() {
    const d = path.join(__dirname, 'runtime', process.platform === 'win32' ? 'win-x64' : process.platform === 'darwin' ? 'mac' : 'linux-x64');
    const f = process.platform === 'win32' ? 'Processing.NDI.Lib.x64.dll' : process.platform === 'darwin' ? 'libndi.dylib' : 'libndi.so.6';
    const env = Object.assign({}, process.env); if (fs.existsSync(path.join(d, f))) { env.NDI_RUNTIME_DIR_V6 = d + (process.platform === 'win32' ? '' : '/'); env.NDI_XIII_BUNDLED = '1'; } return env;
}
const BUNDLED = () => runtimeEnv().NDI_XIII_BUNDLED === '1';

// ---------- une sortie NDI ----------
class Out {
    constructor(n) { this.n = n; this.st = 'arrêtée'; this.conns = 0; this.sent = 0; this.fps = 0; this.frames = 0; this.thumb = ''; this.win = null; this.helper = null; this.timer = null; this.frame = null; this.fresh = false; this.writable = true; this.retry = null; this.lastThumb = 0; this.paints = 0; this.lvl = [0, 0]; this.ast = ''; this.apk = 0; }
    get cfg() { return CFG.outs[this.n - 1]; }
    url() { return 'http://127.0.0.1:' + CFG.port + '/graphico.html?out=' + encodeURIComponent(ROOM || 'graphico') + '&s=' + this.n + '&ws=auto&nobc'; }
    start() {
        this.stop(); if (!this.cfg.on) { this.st = 'désactivée'; return; }
        const W = CFG.w, H = CFG.h, [N, D] = FPS[CFG.fps], rate = N / D, V = this.cfg.video !== false, A = !!(this.cfg.audio && this.cfg.audio.dev);
        if (!V && !A) { this.st = 'rien à envoyer'; return; } this.mode = (V ? 'v' : '') + (A ? 'a' : '');
        if (V) this.startVideo(W, H, rate);
        this.startHelper(W, H, N, D, rate);
        if (A) { this.ast = 'ouverture…'; audioCmd('start', Object.assign({ n: this.n }, this.cfg.audio)); }
    }
    startVideo(W, H, rate) {
        // page de sortie Graphico, rendue hors écran, fond transparent
        const win = this.win = new BrowserWindow({ show: false, width: W, height: H, useContentSize: true, frame: false, transparent: true, backgroundColor: '#00000000', paintWhenInitiallyHidden: true, webPreferences: { offscreen: true, backgroundThrottling: false, contextIsolation: true, sandbox: true } });
        const wc = win.webContents; wc.setFrameRate(Math.min(60, Math.ceil(rate))); wc.setUserAgent(wc.getUserAgent() + ' GraphicoNDI/' + VERSION + ' NDIXIII/' + VERSION); wc.setAudioMuted(true);
        wc.on('paint', (e, dirty, img) => {
            const sz = img.getSize(); if (sz.width !== W || sz.height !== H) img = img.resize({ width: W, height: H, quality: 'good' });
            this.frame = img.toBitmap(); this.fresh = true; this.paints++;
            const now = Date.now(); if (panel && now - this.lastThumb > 700) { this.lastThumb = now; this.thumb = img.resize({ width: 256 }).toDataURL(); }
        });
        wc.on('render-process-gone', () => { log('Sortie ' + this.n + ' : page relancée'); setTimeout(() => this.start(), 1000); });
        wc.loadURL(this.url());
    }
    startHelper(W, H, N, D, rate) {
        // émetteur NDI
        const bin = helperPath(); if (!fs.existsSync(bin)) { this.st = 'émetteur NDI introuvable'; log(this.st + ' : ' + bin); return; }
        const h = this.helper = spawn(bin, [this.cfg.name || ('GRAPHICO - Sortie ' + this.n), String(W), String(H), String(N), String(D), CFG.unpremul ? '1' : '0', this.mode, '48000', '2'], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, env: runtimeEnv() });
        this.st = 'démarrage…'; let buf = '';
        h.stdout.on('data', d => { buf += d.toString(); let i; while ((i = buf.indexOf('\n')) >= 0) { const l = buf.slice(0, i).trim(); buf = buf.slice(i + 1); this.onLine(l); } });
        h.stderr.on('data', d => log('Sortie ' + this.n + ' : ' + d.toString().trim()));
        h.stdin.on('error', () => { });
        h.on('error', e => { this.st = 'erreur : ' + e.message; log('Sortie ' + this.n + ' : ' + e.message); });
        h.on('exit', (code, sig) => { if (this.helper !== h) return; this.helper = null; clearInterval(this.timer); if (quitting) return; if (this.st.indexOf('runtime') >= 0 || code === 3) return; this.st = 'émetteur arrêté (' + (sig || code) + ') — relance…'; log('Sortie ' + this.n + ' : ' + this.st); this.retry = setTimeout(() => this.start(), 2000); });
        // envoi des images neuves (l'émetteur répète lui-même la dernière image à cadence fixe)
        this.timer = setInterval(() => {
            if (!this.fresh || !this.helper || !this.writable || !this.frame) return; this.fresh = false; this.frames++;
            const hd = Buffer.alloc(5); hd[0] = 86; hd.writeUInt32LE(this.frame.length, 1); this.helper.stdin.write(hd);
            const ok = this.helper.stdin.write(this.frame); if (!ok) { this.writable = false; this.helper.stdin.once('drain', () => { this.writable = true; }); }
        }, Math.max(4, Math.floor(1000 / rate / 2)));
    }
    pcm(buf) { if (!this.helper || !this.mode || this.mode.indexOf('a') < 0 || this.st !== 'ok') return; const b = Buffer.from(buf), hd = Buffer.alloc(5); hd[0] = 65; hd.writeUInt32LE(b.length, 1); this.helper.stdin.write(hd); this.helper.stdin.write(b); }
    onLine(l) {
        if (l === 'OK') { this.st = 'ok'; RUNTIME = true; log('Sortie ' + this.n + ' publiée en NDI : « ' + this.cfg.name + ' »'); }
        else if (l.indexOf('ERR') === 0) {
            const m = l.slice(4); if (/RUNTIME_ABSENT/.test(m)) { RUNTIME = false; this.st = 'runtime NDI absent'; } else if (/INCOMPATIBLE/.test(m)) this.st = 'runtime NDI incompatible'; else this.st = 'erreur : ' + m; log('Sortie ' + this.n + ' : ' + this.st);
        } else if (l[0] === 'C') { const p = l.split(' '); this.conns = +p[1] || 0; const s = +p[2] || 0; this.fps = this.sent ? s - this.sent : 0; this.sent = s; const a = +p[3] || 0; this.aps = this.apk ? a - this.apk : 0; this.apk = a; }
        push();
    }
    stop() {
        clearTimeout(this.retry); clearInterval(this.timer); this.timer = null; audioCmd('stop', this.n); this.ast = ''; this.lvl = [0, 0]; this.mode = '';
        if (this.helper) { const h = this.helper; this.helper = null; try { h.stdin.end(); } catch (e) { } setTimeout(() => { try { h.kill(); } catch (e) { } }, 800); }
        if (this.win) { try { this.win.destroy(); } catch (e) { } this.win = null; }
        this.frame = null; this.fresh = false; this.writable = true; this.conns = 0; this.st = 'arrêtée'; this.thumb = '';
    }
    reload() { if (this.win) this.win.webContents.loadURL(this.url()); }
    info() { const a = this.cfg.audio || ADEF; return { s: this.n, on: !!this.cfg.on, name: this.cfg.name, st: this.st, conns: this.conns, fps: this.fps, frames: this.frames, video: this.cfg.video !== false, audio: { dev: a.dev, label: a.label, chan: a.chan, gain: a.gain, mute: a.mute, st: this.ast, lvl: this.lvl, aps: this.aps || 0 } }; }
}
function restartAll() { [1, 2, 3, 4].forEach(n => OUTS[n].start()); push(); }
function setRoom(r, why) { r = String(r || '').toLowerCase().replace(/[^a-z0-9-]+/g, '').slice(0, 24); if (!r || r === ROOM) return; ROOM = r; CFG.room = r; saveCfg(); log('Salle « ' + r + ' »' + (why ? ' (' + why + ')' : '')); Object.values(OUTS).forEach(o => o.reload()); push(); }

// ---------- sources NDI envoyées par les outils de la suite (MELANGO…) ----------
const TOOLS = new Set();
function toolSend(h, q) {
    const T = { app: q.get('app') || 'XIII', name: '', w: 0, h: 0, st: 'attente des réglages', conns: 0, frames: 0, fps: 0, sent: 0, helper: null, busy: false, t0: Date.now() };
    TOOLS.add(T); log('Outil connecté : ' + T.app); push();
    const stop = () => { if (T.helper) { const x = T.helper; T.helper = null; try { x.stdin.end(); } catch (e) { } setTimeout(() => { try { x.kill(); } catch (e) { } }, 800); } };
    h.text = t => {
        let o; try { o = JSON.parse(t); } catch (e) { return; } if (o.k !== 'open') return; stop();
        const W = +o.w | 0, H = +o.h | 0, fr = FPS[String(o.fps)] || FPS['25']; if (W < 16 || H < 16) return; T.w = W; T.h = H; T.name = String(o.name || (T.app + ' - Programme')).slice(0, 60); T.audio = !!o.audio;
        const bin = helperPath(); if (!fs.existsSync(bin)) { T.st = 'émetteur NDI introuvable'; h.send(JSON.stringify({ k: 'st', st: T.st })); return; }
        const x = T.helper = spawn(bin, [T.name, String(W), String(H), String(fr[0]), String(fr[1]), '0', T.audio ? 'va' : 'v', String(+o.rate || 48000), '2'], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, env: runtimeEnv() });
        T.st = 'démarrage…'; let buf = '';
        x.stdout.on('data', d => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { const l = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
            if (l === 'OK') { T.st = 'ok'; RUNTIME = true; log('« ' + T.name + ' » publiée en NDI (' + T.app + ')'); } else if (l.indexOf('ERR') === 0) { T.st = /RUNTIME_ABSENT/.test(l) ? 'runtime NDI absent' : 'erreur : ' + l.slice(4); if (/RUNTIME_ABSENT/.test(l)) RUNTIME = false; }
            else if (l[0] === 'C') { const p = l.split(' '); T.conns = +p[1] || 0; const s2 = +p[2] || 0; T.fps = T.sent ? s2 - T.sent : 0; T.sent = s2; }
            h.send(JSON.stringify({ k: 'st', st: T.st, conns: T.conns, fps: T.fps, runtime: RUNTIME })); push(); } });
        x.stdin.on('error', () => { }); x.on('exit', () => { if (T.helper === x) { T.helper = null; T.st = 'émetteur arrêté'; h.send(JSON.stringify({ k: 'st', st: T.st })); push(); } });
        x.stdin.on('drain', () => { T.busy = false; });
    };
    h.bin = d => {
        if (!T.helper || T.st !== 'ok') return; const t = d[0];
        if (t === 86 || t === 66) { if (T.busy || d.length - 1 !== T.w * T.h * 4) return; const f = d.subarray(1); if (t === 86) for (let i = 0; i < f.length; i += 4) { const r = f[i]; f[i] = f[i + 2]; f[i + 2] = r; } // 'V' RGBA → BGRA ; 'B' déjà en BGRA (lecture GPU)
            const hd = Buffer.alloc(5); hd[0] = 86; hd.writeUInt32LE(f.length, 1); T.helper.stdin.write(hd); if (!T.helper.stdin.write(f)) T.busy = true; T.frames++; }
        else if (t === 65 && T.audio) { const f = d.subarray(1), hd = Buffer.alloc(5); hd[0] = 65; hd.writeUInt32LE(f.length, 1); T.helper.stdin.write(hd); T.helper.stdin.write(f); }
    };
    h.close = () => { stop(); TOOLS.delete(T); log('Outil déconnecté : ' + T.app + (T.name ? ' (« ' + T.name + ' »)' : '')); push(); };
    h.send(JSON.stringify({ k: 'hello', app: 'NDI XIII', version: VERSION, runtime: RUNTIME, host: os.hostname().toUpperCase() }));
}
const toolsInfo = () => [...TOOLS].map(T => ({ app: T.app, name: T.name, w: T.w, h: T.h, st: T.st, conns: T.conns, fps: T.fps, frames: T.frames }));

// ---------- 📡 passerelle de diffusion RTMP / RTMPS / SRT (ffmpeg) ----------
function ffmpegPath() {
    const ex = process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg', loc = path.join(__dirname, 'ffmpeg', ex); if (fs.existsSync(loc)) return loc;
    try { const p = require('ffmpeg-static'); if (p && fs.existsSync(p)) return p; } catch (e) { }
    return ex; // dans le PATH
}
const STREAMS = new Set();
function streamHook(h, q) {
    const T = { app: q.get('app') || 'XIII', dest: '', st: 'attente des réglages', kbps: 0, fps: 0, time: '', bytes: 0, ff: null, t0: Date.now(), err: '' };
    STREAMS.add(T); push();
    const tell = () => { h.send(JSON.stringify({ k: 'st', st: T.st, kbps: T.kbps, fps: T.fps, time: T.time, err: T.err })); push(); };
    const stop = () => { if (T.ff) { const x = T.ff; T.ff = null; try { x.stdin.end(); } catch (e) { } setTimeout(() => { try { x.kill('SIGKILL'); } catch (e) { } }, 3000); } };
    h.text = t => {
        let o; try { o = JSON.parse(t); } catch (e) { return; } if (o.k !== 'open') return; stop();
        let url = String(o.url || '').trim(); if (o.key) url = url.replace(/\/+$/, '') + '/' + String(o.key).trim();
        if (!/^(rtmps?|srt):\/\//i.test(url)) { T.st = 'adresse invalide'; tell(); return; }
        const srt = /^srt:/i.test(url), vb = Math.max(500, Math.min(20000, +o.vb || 4500)), fps = Math.max(10, Math.min(60, +o.fps || 25)), copy = o.mode === 'copy';
        T.dest = url.replace(/\/[^/]{6,}$/, '/••••••').replace(/(passphrase=)[^&]+/i, '$1••••');
        const args = ['-hide_banner', '-loglevel', 'error', '-stats', '-fflags', '+genpts', '-i', 'pipe:0',
            ...(copy ? ['-c:v', 'copy'] : ['-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'zerolatency', '-pix_fmt', 'yuv420p', '-r', String(fps), '-g', String(fps * 2), '-keyint_min', String(fps * 2), '-b:v', vb + 'k', '-maxrate', vb + 'k', '-bufsize', (vb * 2) + 'k']),
            '-c:a', 'aac', '-b:a', '160k', '-ar', '48000', '-ac', '2', '-f', srt ? 'mpegts' : 'flv', url];
        let x; try { x = T.ff = spawn(ffmpegPath(), args, { stdio: ['pipe', 'ignore', 'pipe'], windowsHide: true }); } catch (e) { T.st = 'ffmpeg introuvable'; tell(); return; }
        T.st = 'connexion…'; T.err = ''; log('Diffusion ' + T.app + ' → ' + T.dest); tell(); let eb = '';
        x.on('error', e => { T.st = e.code === 'ENOENT' ? 'ffmpeg introuvable' : 'erreur : ' + e.message; tell(); });
        x.stderr.on('data', d => { eb += d.toString(); const parts = eb.split(/[\r\n]+/); eb = parts.pop();
            parts.forEach(l => { const m = /frame=\s*(\d+).*?fps=\s*([\d.]+).*?time=(\S+).*?bitrate=\s*([\d.]+)/.exec(l); if (m) { T.st = 'en direct'; T.fps = +m[2]; T.time = m[3]; T.kbps = +m[4]; } else if (l.trim()) { T.err = l.trim().slice(0, 200); log('Diffusion : ' + T.err); } }); tell(); });
        x.stdin.on('error', () => { });
        x.on('exit', c => { if (T.ff !== x) return; T.ff = null; T.st = c === 0 ? 'terminée' : 'coupée (' + (T.err || 'code ' + c) + ')'; log('Diffusion ' + T.app + ' : ' + T.st); tell(); });
    };
    h.bin = d => { if (T.ff) { T.bytes += d.length; T.ff.stdin.write(d); } };
    h.close = () => { stop(); STREAMS.delete(T); log('Diffusion ' + T.app + ' arrêtée'); push(); };
    h.send(JSON.stringify({ k: 'hello', app: 'NDI XIII', version: VERSION }));
}
const streamsInfo = () => [...STREAMS].map(T => ({ app: T.app, dest: T.dest, st: T.st, kbps: T.kbps, fps: T.fps, time: T.time }));

// ---------- 🔌 API MELANGO : HTTP (Companion, Stream Deck, scripts) et OSC ----------
//  GET http://ADRESSE:8787/__melango?a=take[&pin=1234]        → exécute l'action (mêmes noms que les raccourcis : pvw:in2, pgm:ddr1, auto, dsk1:auto, ddr1:play, mem3, ptz:in1:2…)
//  GET http://ADRESSE:8787/__melango?a=tbar&v=0.5             → T-bar
//  GET http://ADRESSE:8787/__melango                          → état (programme, preview, REC…) et liste des actions
//  OSC (UDP 8788) : /melango/take · /melango/pvw/in2 · /melango/tbar 0.5
function melRoom() { return srv && srv.rooms && srv.rooms.get('melango-remote'); }
function melSend(o) { const r = melRoom(); let n = 0; if (r) r.clients.forEach(c => { if (c.role === 'ctl') { c.send(JSON.stringify(Object.assign({ k: 'rcmd' }, o))); n++; } }); return n; }
function melState() { const r = melRoom(); try { return r && r.state ? JSON.parse(r.state) : null; } catch (e) { return null; } }
function melApi(q) {
    const st = melState();
    if (!q.a) return st ? { ok: true, connected: true, programme: st.pgmN, preview: st.pvwN, rec: st.rec, stream: st.stream, projet: st.prog, actions: st.acts || {} } : { ok: false, err: 'MELANGO non connecté (Sorties › Télécommande web › Autoriser)' };
    const o = { pin: q.pin || '' }; if (q.a === 'tbar') o.tbar = Math.max(0, Math.min(1, +q.v || 0)); else o.a = String(q.a).slice(0, 60);
    const n = melSend(o); if (!n) return { ok: false, err: 'MELANGO non connecté (Sorties › Télécommande web › Autoriser)' };
    if (o.a && st && st.acts && !st.acts[o.a]) return { ok: false, err: 'action inconnue : ' + o.a };
    return { ok: true, action: o.a || 'tbar' };
}
function oscStart() {
    const sock = require('dgram').createSocket('udp4'); sock.on('error', e => log('OSC : ' + e.message));
    const str = (b, i) => { let e = b.indexOf(0, i); const s = b.toString('utf8', i, e); return [s, (e + 4) & ~3]; };
    sock.on('message', b => { try { let [addr, i] = str(b, 0); if (!/^\/melango\//.test(addr)) return; let tags = ''; if (b[i] === 0x2c) [tags, i] = str(b, i); let v = null; if (tags[1] === 'f') v = b.readFloatBE(i); else if (tags[1] === 'i') v = b.readInt32BE(i); else if (tags[1] === 's') v = str(b, i)[0];
        const path = addr.slice(9).replace(/\//g, ':'); if (path === 'tbar') melApi({ a: 'tbar', v }); else if (v === null || v === 1 || v === '1' || tags[1] === 's') melApi({ a: path, pin: tags[1] === 's' ? v : '' }); } catch (e) { } });
    sock.bind(CFG.port + 1, () => log('OSC prêt : UDP ' + (CFG.port + 1) + ' (/melango/…)'));
}

// ---------- capture audio (fenêtre cachée) ----------
function audioCmd(ch, d) { if (audioWin && !audioWin.isDestroyed()) audioWin.webContents.send(ch, d); }
function openAudio() {
    audioWin = new BrowserWindow({ show: false, width: 300, height: 200, webPreferences: { preload: path.join(__dirname, 'preload-audio.js'), contextIsolation: true, sandbox: true, backgroundThrottling: false } });
    audioWin.loadFile(path.join(__dirname, 'audio.html'));
    audioWin.webContents.on('render-process-gone', () => { log('Audio : capture relancée'); audioWin = null; setTimeout(() => { openAudio(); audioWin.webContents.once('did-finish-load', () => Object.values(OUTS).forEach(o => { if (o.mode && o.mode.indexOf('a') >= 0) audioCmd('start', Object.assign({ n: o.n }, o.cfg.audio)); })); }, 1000); });
}
ipcMain.on('a-pcm', (e, n, buf) => { const o = OUTS[n]; if (o) o.pcm(buf); });
ipcMain.on('a-level', (e, n, l, r) => { const o = OUTS[n]; if (o) o.lvl = [Math.max(o.lvl[0] * .6, l), Math.max(o.lvl[1] * .6, r)]; });
ipcMain.on('a-ok', (e, n, i) => { const o = OUTS[n]; if (!o) return; o.ast = 'ok'; log('Sortie ' + n + ' : son « ' + (i.label || '?') + ' » (' + (i.ch || '?') + ' voie' + (i.ch > 1 ? 's' : '') + ', ' + i.rate + ' Hz)'); push(); });
ipcMain.on('a-err', (e, n, m) => { const o = OUTS[n]; if (!o) return; o.ast = /NotAllowed|Permission/i.test(m) ? 'micro refusé (autorisez l\'accès au micro)' : /NotFound|Overconstrained/i.test(m) ? 'entrée son introuvable' : 'erreur son'; log('Sortie ' + n + ' : ' + o.ast + ' — ' + m); push(); });
ipcMain.on('a-devices', (e, list) => { DEVICES = list || []; push(); });

// ---------- relais + page ----------
function startRelay() {
    srv = relay.start({
        port: CFG.port, dir: path.join(__dirname, 'www'),
        log: s => log('Relais ' + s),
        emit: (ev, d) => { if (ev === 'join' && d.role === 'ctl' && CFG.follow) setRoom(d.room, 'pupitre connecté'); },
        send: toolSend, hooks: { '/__stream': streamHook }, http: { '/__ptz': q => require('./ptz.js').ptz(q), '/__melango': melApi },
        xiii: () => ({ app: 'NDI XIII', version: VERSION, host: os.hostname().toUpperCase(), runtime: RUNTIME, bundled: BUNDLED(), services: ['graphico', 'send', 'stream', 'ptz', 'api'], ffmpeg: ffmpegPath() !== (process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg') || null, streams: streamsInfo(), graphico: [1, 2, 3, 4].map(n => OUTS[n].info()), tools: toolsInfo() }),
        status: () => ({ ndi: { app: 'NDI XIII ' + VERSION, host: os.hostname().toUpperCase(), runtime: RUNTIME, room: ROOM, w: CFG.w, h: CFG.h, fps: CFG.fps, outs: [1, 2, 3, 4].map(n => OUTS[n].info()) } }),
        onError: e => { log(e.code === 'EADDRINUSE' ? '⚠️ Le port ' + CFG.port + ' est déjà utilisé (un relais Graphico est peut-être déjà lancé). Changez le port dans les réglages.' : '⚠️ ' + e.message); },
        ready: () => { log('Relais prêt : http://localhost:' + CFG.port + '/'); restartAll(); try { oscStart(); } catch (e) { } }
    });
}
function state() {
    return { version: VERSION, port: CFG.port, ips: relay.lanIps(), host: os.hostname(), room: ROOM, follow: CFG.follow, w: CFG.w, h: CFG.h, fps: CFG.fps, unpremul: CFG.unpremul, runtime: RUNTIME, platform: process.platform,
        outs: [1, 2, 3, 4].map(n => Object.assign(OUTS[n].info(), { thumb: OUTS[n].thumb })), tools: toolsInfo(), streams: streamsInfo(), bundled: BUNDLED(), logs: LOGS.slice(-60), devices: DEVICES,
        clients: srv ? [...srv.rooms.values()].reduce((a, r) => a + r.clients.size, 0) : 0 };
}
let pushT = null; function push() { if (pushT) return; pushT = setTimeout(() => { pushT = null; if (panel && !panel.isDestroyed()) panel.webContents.send('state', state()); }, 120); }
setInterval(push, 1000);

// ---------- fenêtre de contrôle ----------
function openPanel() {
    panel = new BrowserWindow({ width: 980, height: 760, minWidth: 760, minHeight: 560, title: 'NDI XIII', backgroundColor: '#1e1e1e', autoHideMenuBar: true, webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, sandbox: true } });
    panel.loadFile(path.join(__dirname, 'panel.html'));
    panel.on('closed', () => { panel = null; app.quit(); });
}
ipcMain.handle('get', () => state());
ipcMain.handle('set', (e, k, v) => {
    if (k === 'out') { const o = CFG.outs[v.n - 1]; if (!o) return; const was = JSON.stringify([o.on, o.name, o.video]); Object.assign(o, v.patch); saveCfg(); if (was !== JSON.stringify([o.on, o.name, o.video])) OUTS[v.n].start(); }
    else if (k === 'audio') {
        const o = CFG.outs[v.n - 1]; if (!o) return; const a = o.audio, wasDev = a.dev, wasChan = a.chan; Object.assign(a, v.patch);
        if (v.patch.dev != null) { const d = DEVICES.find(x => x.id === a.dev); a.label = d ? d.label : ''; }
        saveCfg(); const O = OUTS[v.n];
        if (!!wasDev !== !!a.dev) O.start(); else if (a.dev && (wasDev !== a.dev || wasChan !== a.chan) && O.mode) { O.ast = 'ouverture…'; audioCmd('start', Object.assign({ n: v.n }, a)); } else audioCmd('params', Object.assign({ n: v.n }, a));
    }
    else if (k === 'devices') audioCmd('list');
    else if (k === 'format') { const [w, h] = String(v).split('x').map(Number); if (w >= 320 && h >= 180) { CFG.w = w; CFG.h = h; saveCfg(); restartAll(); } }
    else if (k === 'fps') { if (FPS[v]) { CFG.fps = v; saveCfg(); restartAll(); } }
    else if (k === 'unpremul') { CFG.unpremul = !!v; saveCfg(); restartAll(); }
    else if (k === 'follow') { CFG.follow = !!v; saveCfg(); }
    else if (k === 'room') setRoom(v, 'réglage manuel');
    else if (k === 'port') { const p = +v; if (p >= 1024 && p <= 65535 && p !== CFG.port) { CFG.port = p; saveCfg(); log('Port changé : relancez Graphico NDI.'); } }
    push(); return state();
});
ipcMain.handle('open', (e, what) => { if (what === 'pupitre') shell.openExternal('http://localhost:' + CFG.port + '/'); else if (what === 'plus') shell.openExternal('http://localhost:' + CFG.port + '/?plus=1'); else if (what === 'ndi') shell.openExternal('https://ndi.video/tools/'); else if (/^https?:\/\//.test(what)) shell.openExternal(what); });
ipcMain.handle('copy', (e, t) => { clipboard.writeText(String(t)); });

app.on('second-instance', () => { if (panel) { if (panel.isMinimized()) panel.restore(); panel.focus(); } });
app.whenReady().then(() => {
    loadCfg(); [1, 2, 3, 4].forEach(n => { OUTS[n] = new Out(n); });
    const media = p => p === 'media' || p === 'audioCapture' || p === 'microphone';
    session.defaultSession.setPermissionRequestHandler((wc, p, cb) => cb(media(p)));
    session.defaultSession.setPermissionCheckHandler((wc, p) => media(p));
    openPanel(); openAudio(); audioWin.webContents.once('did-finish-load', () => startRelay());
});
app.on('before-quit', () => { quitting = true; Object.values(OUTS).forEach(o => o.stop()); });
app.on('window-all-closed', () => app.quit());
