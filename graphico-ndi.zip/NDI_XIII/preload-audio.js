const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('gaudio', {
    on: (ch, f) => ipcRenderer.on(ch, (e, d) => f(d)),
    pcm: (n, buf) => ipcRenderer.send('a-pcm', n, buf),
    level: (n, l, r) => ipcRenderer.send('a-level', n, l, r),
    err: (n, m) => ipcRenderer.send('a-err', n, m),
    ok: (n, info) => ipcRenderer.send('a-ok', n, info),
    devices: list => ipcRenderer.send('a-devices', list)
});
