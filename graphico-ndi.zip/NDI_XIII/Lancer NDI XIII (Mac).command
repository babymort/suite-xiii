#!/bin/bash
# NDI XIII — lanceur macOS
cd "$(dirname "$0")"
xattr -dr com.apple.quarantine . 2>/dev/null
if ! command -v node >/dev/null 2>&1; then echo "Node.js est introuvable : installez la version LTS depuis https://nodejs.org puis relancez."; open https://nodejs.org; read -p "Entrée pour fermer"; exit 1; fi
if [ ! -d node_modules/electron/dist ] || [ ! -d node_modules/ffmpeg-static ]; then echo "Première installation : téléchargement d'Electron (une seule fois, ~100 Mo)…"; npm install --no-audit --no-fund || { read -p "Installation impossible. Entrée pour fermer"; exit 1; }; fi
# si les outils de développement Apple sont présents, on recompile l'émetteur NDI pour ce Mac (plus sûr qu'un binaire non signé)
if xcode-select -p >/dev/null 2>&1 && [ ! -x bin/mac/ndi-send-local ]; then cc -O2 -o bin/mac/ndi-send-local src/ndi-send.c 2>/dev/null && echo "Émetteur NDI compilé pour ce Mac."; fi
chmod +x bin/mac/ndi-send 2>/dev/null
nohup ./node_modules/.bin/electron . >/dev/null 2>&1 &
sleep 2
