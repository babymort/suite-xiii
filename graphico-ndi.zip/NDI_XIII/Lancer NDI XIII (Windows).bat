@echo off
chcp 65001 >nul
title NDI XIII
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js est introuvable. Installez la version LTS depuis https://nodejs.org puis relancez ce fichier.
  start https://nodejs.org
  pause
  exit /b 1
)
set NEED=0
if not exist "node_modules\electron\dist\electron.exe" set NEED=1
if not exist "node_modules\ffmpeg-static" set NEED=1
if "%NEED%"=="1" (
  echo Premiere installation : telechargement d'Electron, une seule fois, environ 100 Mo...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo Installation impossible : verifiez la connexion internet.
    pause
    exit /b 1
  )
)
start "" "node_modules\electron\dist\electron.exe" .
