/* =====================================================================
   GRAPHICO NDI — émetteur NDI minimal (sans dépendance, le runtime NDI est chargé à l'exécution)
   ndi-send "Nom NDI" largeur hauteur fps_num fps_den unpremul(0|1) mode(v|a|va) frequence canaux
   Lit sur l'entrée standard des paquets : 1 octet de type + 4 octets de longueur (petit-boutiste) + données
     'V' : image BGRA brute (largeur*hauteur*4 octets) — publiée à cadence fixe, la dernière image est répétée
     'A' : son PCM float 32 bits entrelacé (canaux × échantillons) — publié dès réception
   Écrit sur la sortie standard : "OK", "ERR <message>", puis chaque seconde "C <récepteurs> <images> <paquets son>".
   Compilation :
     Windows (depuis Linux) : voir build.sh (clang --target=x86_64-pc-windows-msvc, sans CRT)
     macOS : clang -O2 -o ndi-send ndi-send.c
     Linux : cc -O2 -o ndi-send ndi-send.c -ldl -lpthread
   NDI® est une marque déposée de Vizrt NDI AB. Le runtime NDI (NDI Tools) doit être installé séparément.
   ===================================================================== */
typedef unsigned char u8; typedef unsigned int u32; typedef long long i64; typedef unsigned long long u64;

/* ---- structures NDI (Processing.NDI.structs.h / Processing.NDI.Send.h, SDK 4 à 6) ---- */
typedef struct { const char *p_ndi_name; const char *p_groups; _Bool clock_video; _Bool clock_audio; } NDIlib_send_create_t;
typedef struct {
    int xres, yres; u32 FourCC; int frame_rate_N, frame_rate_D; float picture_aspect_ratio; int frame_format_type;
    i64 timecode; u8 *p_data; int line_stride_in_bytes; const char *p_metadata; i64 timestamp;
} NDIlib_video_frame_v2_t;
#define FOURCC_BGRA ((u32)'B' | ((u32)'G' << 8) | ((u32)'R' << 16) | ((u32)'A' << 24))
#define NDI_TIMECODE_SYNTH 0x7fffffffffffffffLL
typedef _Bool (*f_init)(void); typedef void *(*f_create)(const NDIlib_send_create_t *); typedef void (*f_video)(void *, const NDIlib_video_frame_v2_t *);
typedef struct { int sample_rate, no_channels, no_samples; i64 timecode; float *p_data; int channel_stride_in_bytes; const char *p_metadata; i64 timestamp; } NDIlib_audio_frame_v2_t;
typedef void (*f_audio)(void *, const NDIlib_audio_frame_v2_t *);
typedef int (*f_conns)(void *, u32); typedef void (*f_destroy)(void *); typedef void (*f_fin)(void);

/* ======================= couche système ======================= */
#ifdef _WIN32
typedef void *HANDLE; typedef unsigned long DWORD; typedef int BOOL; typedef void *HMODULE;
__declspec(dllimport) HANDLE __stdcall GetStdHandle(DWORD);
__declspec(dllimport) BOOL __stdcall ReadFile(HANDLE, void *, DWORD, DWORD *, void *);
__declspec(dllimport) BOOL __stdcall WriteFile(HANDLE, const void *, DWORD, DWORD *, void *);
__declspec(dllimport) HMODULE __stdcall LoadLibraryA(const char *);
__declspec(dllimport) void *__stdcall GetProcAddress(HMODULE, const char *);
__declspec(dllimport) DWORD __stdcall GetEnvironmentVariableA(const char *, char *, DWORD);
__declspec(dllimport) void __stdcall ExitProcess(unsigned);
__declspec(dllimport) void *__stdcall VirtualAlloc(void *, u64, DWORD, DWORD);
__declspec(dllimport) char *__stdcall GetCommandLineA(void);
__declspec(dllimport) HANDLE __stdcall CreateThread(void *, u64, DWORD(__stdcall *)(void *), void *, DWORD, DWORD *);
__declspec(dllimport) void __stdcall Sleep(DWORD);
__declspec(dllimport) DWORD __stdcall GetTickCount(void);
int _fltused = 0;
void *memset(void *d, int c, u64 n) { u8 *p = d; while (n--) *p++ = (u8)c; return d; }
void *memcpy(void *d, const void *s, u64 n) { u8 *p = d; const u8 *q = s; while (n--) *p++ = *q++; return d; }
static HANDLE hin, hout;
static long sys_read(void *b, u64 n) { DWORD r = 0; if (!ReadFile(hin, b, (DWORD)n, &r, 0)) return 0; return (long)r; }
static void sys_write(const char *s, u64 n) { DWORD w; WriteFile(hout, s, (DWORD)n, &w, 0); }
static void *sys_alloc(u64 n) { return VirtualAlloc(0, n, 0x3000, 0x04); }
static void sys_exit(int c) { ExitProcess((unsigned)c); }
static void sys_sleep_ms(int ms) { Sleep((DWORD)ms); }
static u32 sys_ms(void) { return GetTickCount(); }
static void *lib_open(void) {
    static const char *envs[] = { "NDI_RUNTIME_DIR_V6", "NDI_RUNTIME_DIR_V5", "NDI_RUNTIME_DIR_V4", 0 }; char p[600]; HMODULE h;
    for (int i = 0; envs[i]; i++) { DWORD n = GetEnvironmentVariableA(envs[i], p, 500); if (n && n < 500) { const char *f = "\\Processing.NDI.Lib.x64.dll"; int k = 0; while (f[k]) { p[n + k] = f[k]; k++; } p[n + k] = 0; h = LoadLibraryA(p); if (h) return h; } }
    h = LoadLibraryA("Processing.NDI.Lib.x64.dll"); return h;
}
static void *lib_sym(void *h, const char *n) { return GetProcAddress((HMODULE)h, n); }
static DWORD __stdcall reader_thunk(void *a);
static void start_reader(void) { CreateThread(0, 0, reader_thunk, 0, 0, 0); }
#else
#include <stddef.h>
extern void *memset(void *, int, size_t); extern long read(int, void *, size_t); extern long write(int, const void *, size_t); extern void *malloc(size_t); extern void exit(int);
extern void *dlopen(const char *, int); extern void *dlsym(void *, const char *); extern char *getenv(const char *); extern int usleep(unsigned);
struct timespec_ { long s; long ns; }; extern int clock_gettime(int, struct timespec_ *);
typedef unsigned long pthread_t_; extern int pthread_create(void *, const void *, void *(*)(void *), void *);
static long sys_read(void *b, u64 n) { long r = read(0, b, n); return r < 0 ? 0 : r; }
static void sys_write(const char *s, u64 n) { write(1, s, n); }
static void *sys_alloc(u64 n) { return malloc(n); }
static void sys_exit(int c) { exit(c); }
static void sys_sleep_ms(int ms) { usleep((unsigned)ms * 1000); }
#ifdef __APPLE__
#define CLOCK_MONO 6
#else
#define CLOCK_MONO 1
#endif
static u32 sys_ms(void) { struct timespec_ t; clock_gettime(CLOCK_MONO, &t); return (u32)(t.s * 1000 + t.ns / 1000000); }
static void *lib_open(void) {
    void *h; const char *e; char p[600];
#ifdef __APPLE__
    static const char *names[] = { "libndi.dylib", "/usr/local/lib/libndi.dylib", "/Library/NDI SDK for Apple/lib/macOS/libndi.dylib", "/Library/NDI SDK for Apple/lib/macos/libndi.dylib", "/Applications/NDI Video Monitor.app/Contents/Frameworks/libndi.dylib", "/Library/Application Support/NewTek/NDI/libndi.dylib", 0 };
    const char *lib = "/libndi.dylib";
#else
    static const char *names[] = { "libndi.so.6", "libndi.so.5", "libndi.so", "/usr/lib/libndi.so", "/usr/local/lib/libndi.so", 0 };
    const char *lib = "/libndi.so";
#endif
    static const char *envs[] = { "NDI_RUNTIME_DIR_V6", "NDI_RUNTIME_DIR_V5", "NDI_RUNTIME_DIR", 0 };
    for (int i = 0; envs[i]; i++) if ((e = getenv(envs[i]))) { int k = 0, j = 0; while (e[k] && k < 500) { p[k] = e[k]; k++; } while (lib[j]) p[k++] = lib[j++]; p[k] = 0; if ((h = dlopen(p, 2))) return h; }
    for (int i = 0; names[i]; i++) if ((h = dlopen(names[i], 2))) return h;
    return 0;
}
static void *lib_sym(void *h, const char *n) { return dlsym(h, n); }
static void *reader_main(void *a);
static void start_reader(void) { pthread_t_ t; pthread_create(&t, 0, reader_main, 0); }
#endif

/* ======================= utilitaires ======================= */
static void out(const char *s) { u64 n = 0; while (s[n]) n++; sys_write(s, n); }
static void out_num(u64 v) { char b[24]; int i = 23; b[i] = 0; if (!v) b[--i] = '0'; while (v) { b[--i] = (char)('0' + v % 10); v /= 10; } out(b + i); }
static int to_int(const char *s) { int v = 0; while (*s >= '0' && *s <= '9') v = v * 10 + (*s++ - '0'); return v; }

/* ======================= lecture des paquets ======================= */
static u8 *buf[3]; static u64 FRAME; static volatile int shared = 1; /* bit 4 : image neuve disponible */
static volatile int eof = 0; static int HASV = 1, HASA = 0, RATE = 48000, CH = 2;
static void *snd; static f_audio aud; static float *abuf, *aplan; static volatile u64 apk = 0;
#define AMAX (48000u * 8u * 4u)
static int read_full(u8 *b, u64 n) { u64 got = 0; while (got < n) { long r = sys_read(b + got, n - got); if (r <= 0) return 0; got += (u64)r; } return 1; }
static void reader(void) {
    int back = 2; u8 h[5]; static u8 junk[65536];
    for (;;) {
        if (!read_full(h, 5)) break; u64 len = (u64)h[1] | ((u64)h[2] << 8) | ((u64)h[3] << 16) | ((u64)h[4] << 24);
        if (h[0] == 'V' && HASV && len == FRAME) { if (!read_full(buf[back], FRAME)) break; back = __atomic_exchange_n(&shared, back | 4, __ATOMIC_ACQ_REL) & 3; }
        else if (h[0] == 'A' && HASA && len <= AMAX && len % (4u * (u64)CH) == 0) {
            if (!read_full((u8 *)abuf, len)) break; int ns = (int)(len / (4u * (u64)CH));
            for (int c = 0; c < CH; c++) for (int i = 0; i < ns; i++) aplan[c * ns + i] = abuf[i * CH + c]; /* entrelacé → plan par canal */
            NDIlib_audio_frame_v2_t af; af.sample_rate = RATE; af.no_channels = CH; af.no_samples = ns; af.timecode = NDI_TIMECODE_SYNTH; af.p_data = aplan; af.channel_stride_in_bytes = ns * 4; af.p_metadata = 0; af.timestamp = 0;
            aud(snd, &af); apk++;
        }
        else { while (len) { u64 k = len > sizeof junk ? sizeof junk : len; if (!read_full(junk, k)) { eof = 1; return; } len -= k; } }
    }
    eof = 1;
}
#ifdef _WIN32
static DWORD __stdcall reader_thunk(void *a) { (void)a; reader(); return 0; }
#else
static void *reader_main(void *a) { (void)a; reader(); return 0; }
#endif
static u8 inv[256 * 256]; /* table de dé-prémultiplication : inv[a*256+c] */
static void unpremul(u8 *p, u64 n) {
    for (u64 i = 0; i < n; i += 4) { u8 a = p[i + 3]; if (a == 255 || a == 0) continue; const u8 *t = inv + a * 256; p[i] = t[p[i]]; p[i + 1] = t[p[i + 1]]; p[i + 2] = t[p[i + 2]]; }
}
static int eq(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a == *b; }

static int run(int argc, char **argv) {
    if (argc < 6) { out("ERR usage: ndi-send nom largeur hauteur fps_num fps_den [unpremul] [v|a|va] [frequence] [canaux]\n"); return 2; }
    const char *name = argv[1]; int W = to_int(argv[2]), H = to_int(argv[3]), FN = to_int(argv[4]), FD = to_int(argv[5]), UP = argc > 6 ? to_int(argv[6]) : 1;
    if (argc > 7) { HASV = eq(argv[7], "v") || eq(argv[7], "va"); HASA = eq(argv[7], "a") || eq(argv[7], "va"); }
    if (argc > 8) RATE = to_int(argv[8]); if (argc > 9) CH = to_int(argv[9]);
    if (W < 16 || H < 16 || W > 8192 || H > 8192 || FN < 1 || FD < 1 || (!HASV && !HASA) || RATE < 8000 || RATE > 192000 || CH < 1 || CH > 8) { out("ERR paramètres invalides\n"); return 2; }
    void *lib = lib_open(); if (!lib) { out("ERR NDI_RUNTIME_ABSENT\n"); return 3; }
    f_init ini = (f_init)lib_sym(lib, "NDIlib_initialize"); f_create cre = (f_create)lib_sym(lib, "NDIlib_send_create"); f_video vid = (f_video)lib_sym(lib, "NDIlib_send_send_video_v2");
    f_conns con = (f_conns)lib_sym(lib, "NDIlib_send_get_no_connections"); f_destroy des = (f_destroy)lib_sym(lib, "NDIlib_send_destroy"); f_fin fin = (f_fin)lib_sym(lib, "NDIlib_destroy");
    aud = (f_audio)lib_sym(lib, "NDIlib_send_send_audio_v2");
    if (!ini || !cre || !vid || (HASA && !aud)) { out("ERR NDI_RUNTIME_INCOMPATIBLE\n"); return 3; }
    if (!ini()) { out("ERR NDI_CPU_NON_SUPPORTE\n"); return 3; }
    NDIlib_send_create_t sc; sc.p_ndi_name = name; sc.p_groups = 0; sc.clock_video = HASV ? 1 : 0; sc.clock_audio = 0;
    snd = cre(&sc); if (!snd) { out("ERR NDI_CREATION_IMPOSSIBLE\n"); return 3; }
    FRAME = (u64)W * (u64)H * 4;
    if (HASV) { for (int i = 0; i < 3; i++) { buf[i] = (u8 *)sys_alloc(FRAME); if (!buf[i]) { out("ERR mémoire\n"); return 4; } memset(buf[i], 0, FRAME); } }
    if (HASA) { abuf = (float *)sys_alloc(AMAX); aplan = (float *)sys_alloc(AMAX); if (!abuf || !aplan) { out("ERR mémoire\n"); return 4; } }
    for (int a = 1; a < 256; a++) for (int c = 0; c < 256; c++) { int v = (c * 255 + a / 2) / a; inv[a * 256 + c] = (u8)(v > 255 ? 255 : v); }
    out("OK\n"); start_reader();
    NDIlib_video_frame_v2_t f; memset(&f, 0, sizeof f); f.xres = W; f.yres = H; f.FourCC = FOURCC_BGRA; f.frame_rate_N = FN; f.frame_rate_D = FD;
    f.picture_aspect_ratio = (float)W / (float)H; f.frame_format_type = 1; f.timecode = NDI_TIMECODE_SYNTH; f.line_stride_in_bytes = W * 4;
    int front = 0; u64 sent = 0; u32 last = sys_ms();
    while (!eof) {
        if (HASV) {
            if (shared & 4) { front = __atomic_exchange_n(&shared, front, __ATOMIC_ACQ_REL) & 3; if (UP) unpremul(buf[front], FRAME); }
            f.p_data = buf[front]; vid(snd, &f); sent++; /* clock_video : l'appel cadence lui-même à fps_num/fps_den */
        } else sys_sleep_ms(50);
        u32 now = sys_ms(); if (now - last >= 1000) { last = now; out("C "); out_num(con ? (u64)con(snd, 0) : 0); out(" "); out_num(sent); out(" "); out_num(apk); out("\n"); }
    }
    if (des) des(snd); if (fin) fin(); return 0;
}

#ifdef _WIN32
/* découpe de la ligne de commande Windows (guillemets simples gérés) */
static char *args_v[16];
void mainCRTStartup(void) {
    hin = GetStdHandle((DWORD)-10); hout = GetStdHandle((DWORD)-11);
    char *c = GetCommandLineA(); int n = 0;
    while (*c && n < 15) { while (*c == ' ' || *c == '\t') c++; if (!*c) break; if (*c == '"') { c++; args_v[n++] = c; while (*c && *c != '"') c++; } else { args_v[n++] = c; while (*c && *c != ' ' && *c != '\t') c++; } if (*c) *c++ = 0; }
    sys_exit(run(n, args_v));
}
#else
int main(int argc, char **argv) { return run(argc, argv); }
#endif
