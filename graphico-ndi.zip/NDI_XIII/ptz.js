// =====================================================================
//  NDI XIII — pilotage des caméras PTZ (le navigateur ne peut pas parler VISCA : le module le fait pour lui)
//  POST /__ptz  { proto, ip, port, cmd, pan, tilt, speed, zoom, preset }
//   proto : 'visca-udp' (Sony / VISCA sur IP, port 52381) · 'visca-tcp' (PTZOptics, Lumens, Marshall… port 5678)
//           'ptzoptics-http' (CGI PTZOptics / HuddleCam / Minrray) · 'panasonic-http' (AW-HE / AW-UE)
//   cmd   : 'move' (pan, tilt de -1 à 1) · 'stop' · 'zoom' (zoom de -1 à 1, 0 = stop) · 'home' · 'recall' · 'store' (preset 1..)
// =====================================================================
const dgram = require('dgram'), net = require('net'), http = require('http');
let seq = 1; const udp = dgram.createSocket('udp4'); udp.on('error', () => { }); const tcp = {};
const hx = n => Math.max(0, Math.min(255, Math.round(n)));
function visca(q) {
    const sp = Math.max(.05, Math.min(1, +q.speed || .5)), P = Math.abs(+q.pan || 0), T = Math.abs(+q.tilt || 0), pr = Math.max(0, Math.min(254, (+q.preset || 1) - 1));
    switch (q.cmd) {
        case 'move': { const ps = hx(1 + P * sp * 23), ts = hx(1 + T * sp * 19), x = (+q.pan || 0) < -.05 ? 1 : (+q.pan || 0) > .05 ? 2 : 3, y = (+q.tilt || 0) > .05 ? 1 : (+q.tilt || 0) < -.05 ? 2 : 3; return [0x81, 1, 6, 1, Math.max(1, ps), Math.max(1, ts), x, y, 0xff]; }
        case 'stop': return [0x81, 1, 6, 1, 1, 1, 3, 3, 0xff];
        case 'zoom': { const z = +q.zoom || 0, v = Math.min(7, Math.round(Math.abs(z) * 7)); return [0x81, 1, 4, 7, z > .05 ? 0x20 | v : z < -.05 ? 0x30 | v : 0, 0xff]; }
        case 'home': return [0x81, 1, 6, 4, 0xff];
        case 'recall': return [0x81, 1, 4, 0x3f, 2, pr, 0xff];
        case 'store': return [0x81, 1, 4, 0x3f, 1, pr, 0xff];
    } return null;
}
function sendTcp(ip, port, buf) {
    return new Promise((ok, ko) => { const k = ip + ':' + port; let s = tcp[k];
        const go = () => { s.write(buf); ok({ ok: true }); };
        if (s && !s.destroyed && s.ready) return go();
        s = tcp[k] = net.connect({ host: ip, port }, () => { s.ready = true; go(); }); s.setNoDelay(true); s.setTimeout(4000, () => { if (!s.ready) { s.destroy(); ko(new Error('caméra injoignable (' + k + ')')); } }); s.on('error', e => { delete tcp[k]; ko(new Error('caméra injoignable (' + e.code + ')')); }); s.on('data', () => { }); s.on('close', () => { if (tcp[k] === s) delete tcp[k]; }); });
}
function get(url) { return new Promise((ok, ko) => { const r = http.get(url, { timeout: 3000 }, res => { res.resume(); ok({ ok: res.statusCode < 400, code: res.statusCode }); }); r.on('timeout', () => { r.destroy(); ko(new Error('caméra injoignable')); }); r.on('error', e => ko(new Error('caméra injoignable (' + e.code + ')'))); }); }
async function ptz(q) {
    const ip = String(q.ip || '').trim(); if (!/^[\w.-]+$/.test(ip)) return { ok: false, err: 'adresse IP invalide' };
    const proto = q.proto || 'visca-udp';
    if (proto === 'visca-udp' || proto === 'visca-tcp') {
        const p = visca(q); if (!p) return { ok: false, err: 'commande inconnue' };
        if (proto === 'visca-tcp') return sendTcp(ip, +q.port || 5678, Buffer.from(p));
        const h = Buffer.alloc(8); h[0] = 1; h[1] = 0; h.writeUInt16BE(p.length, 2); h.writeUInt32BE(seq++ >>> 0, 4);
        return new Promise(ok => udp.send(Buffer.concat([h, Buffer.from(p)]), +q.port || 52381, ip, e => ok(e ? { ok: false, err: e.message } : { ok: true })));
    }
    const sp = Math.max(.05, Math.min(1, +q.speed || .5));
    if (proto === 'ptzoptics-http') {
        const b = 'http://' + ip + (q.port && +q.port !== 80 ? ':' + q.port : '') + '/cgi-bin/ptzctrl.cgi?ptzcmd&', ps = Math.max(1, Math.round(Math.abs(+q.pan || 0) * sp * 24)), ts = Math.max(1, Math.round(Math.abs(+q.tilt || 0) * sp * 20)), pn = +q.pan || 0, tl = +q.tilt || 0, z = +q.zoom || 0;
        const c = q.cmd === 'move' ? ((pn < -.05 ? 'left' : pn > .05 ? 'right' : '') + (tl > .05 ? 'up' : tl < -.05 ? 'down' : '') || 'ptzstop') + '&' + ps + '&' + ts : q.cmd === 'stop' ? 'ptzstop' : q.cmd === 'zoom' ? (z > .05 ? 'zoomin&' + Math.max(1, Math.round(z * 7)) : z < -.05 ? 'zoomout&' + Math.max(1, Math.round(-z * 7)) : 'zoomstop') : q.cmd === 'home' ? 'home' : q.cmd === 'recall' ? 'poscall&' + (+q.preset || 1) : q.cmd === 'store' ? 'posset&' + (+q.preset || 1) : '';
        return get(b + c);
    }
    if (proto === 'panasonic-http') {
        const b = 'http://' + ip + (q.port && +q.port !== 80 ? ':' + q.port : '') + '/cgi-bin/aw_ptz?res=1&cmd=', v = x => String(Math.max(1, Math.min(99, Math.round(50 + x * sp * 49)))).padStart(2, '0'), pr = String(Math.max(0, (+q.preset || 1) - 1)).padStart(2, '0');
        const c = q.cmd === 'move' ? '%23PTS' + v(+q.pan || 0) + v(+q.tilt || 0) : q.cmd === 'stop' ? '%23PTS5050' : q.cmd === 'zoom' ? '%23Z' + v(+q.zoom || 0) : q.cmd === 'home' ? '%23APC80008000' : q.cmd === 'recall' ? '%23R' + pr : q.cmd === 'store' ? '%23M' + pr : '';
        return get(b + c);
    }
    return { ok: false, err: 'protocole inconnu' };
}
module.exports = { ptz };
